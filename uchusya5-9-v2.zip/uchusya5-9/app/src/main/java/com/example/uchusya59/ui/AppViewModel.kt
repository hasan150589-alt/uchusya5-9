package com.example.uchusya59.ui
import androidx.lifecycle.ViewModel
import com.example.uchusya59.ai.TutorEngine
import com.example.uchusya59.model.demoSubjects
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
class AppViewModel:ViewModel(){
 private val tutor=TutorEngine()
 private val _question=MutableStateFlow("")
 val question=_question.asStateFlow()
 private val _answer=MutableStateFlow("Задай вопрос, и мы разберём его вместе.")
 val answer=_answer.asStateFlow()
 val subjects=demoSubjects
 fun setQuestion(v:String){_question.value=v}
 fun ask(){_answer.value=tutor.answer(_question.value)}
}
