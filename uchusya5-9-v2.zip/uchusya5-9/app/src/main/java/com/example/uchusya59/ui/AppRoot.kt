package com.example.uchusya59.ui
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.uchusya59.ui.screens.*
@Composable fun AppRoot(vm:AppViewModel=viewModel()){
 var tab by remember{mutableIntStateOf(0)}
 Scaffold(bottomBar={NavigationBar{
  NavigationBarItem(tab==0,{tab=0},{Icon(Icons.Default.Home,null)},label={Text("Главная")})
  NavigationBarItem(tab==1,{tab=1},{Icon(Icons.Default.School,null)},label={Text("Предметы")})
  NavigationBarItem(tab==2,{tab=2},{Icon(Icons.Default.SmartToy,null)},label={Text("ИИ")})
  NavigationBarItem(tab==3,{tab=3},{Icon(Icons.Default.Person,null)},label={Text("Профиль")})
 }}){p->when(tab){0->HomeScreen(Modifier.padding(p));1->SubjectsScreen(vm,Modifier.padding(p));2->TutorScreen(vm,Modifier.padding(p));else->ProfileScreen(Modifier.padding(p))}}
}
