package com.example.uchusya59
import android.app.Application
import androidx.room.Room
import com.example.uchusya59.data.AppDatabase
class UchusyaApp: Application() {
 val database by lazy { Room.databaseBuilder(this,AppDatabase::class.java,"uchusya.db").fallbackToDestructiveMigration().build() }
}
