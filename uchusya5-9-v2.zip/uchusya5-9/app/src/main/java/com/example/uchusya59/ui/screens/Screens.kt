package com.example.uchusya59.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.uchusya59.ui.AppViewModel
import com.example.uchusya59.model.demoSubjects

@Composable fun HomeScreen(m:Modifier=Modifier){LazyColumn(modifier=m.fillMaxSize(),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
 item{Text("Учусь 5–9",style=MaterialTheme.typography.headlineLarge);Text("Твой учебный помощник")}
 item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Продолжить обучение",style=MaterialTheme.typography.titleLarge);Text("Математика • 7 класс");LinearProgressIndicator({0.68f},Modifier.fillMaxWidth());Button({}){Text("Продолжить")}}}}
 item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("Сегодня",style=MaterialTheme.typography.titleLarge);Text("15 минут практики — следующий шаг.")}}}
}}
@Composable fun SubjectsScreen(vm:AppViewModel,m:Modifier=Modifier){LazyColumn(modifier=m.fillMaxSize(),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Предметы",style=MaterialTheme.typography.headlineMedium)};items(demoSubjects){s->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("${s.icon}  ${s.name}",style=MaterialTheme.typography.titleLarge);LinearProgressIndicator({s.progress/100f},Modifier.fillMaxWidth());Text("${s.progress}% освоено");OutlinedButton({}){Text("Открыть")}}}}}}
@Composable fun TutorScreen(vm:AppViewModel,m:Modifier=Modifier){val q by vm.question.collectAsState();val a by vm.answer.collectAsState();Column(m.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("ИИ-репетитор",style=MaterialTheme.typography.headlineMedium);Text("Задай вопрос своими словами.");OutlinedTextField(q,vm::setQuestion,Modifier.fillMaxWidth().heightIn(min=120.dp),label={Text("Твой вопрос")});Button(vm::ask,Modifier.fillMaxWidth()){Text("Объяснить")};Card(Modifier.fillMaxWidth()){Text(a,Modifier.padding(18.dp))}}}
@Composable fun ProfileScreen(m:Modifier=Modifier){Column(m.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){Text("Профиль",style=MaterialTheme.typography.headlineMedium);Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Мой прогресс",style=MaterialTheme.typography.titleLarge);Text("Занятий: 24");Text("Заданий: 186");Text("Серия: 6 дней")}}}}
