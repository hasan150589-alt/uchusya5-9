package com.example.uchusya59.ui
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
@Composable fun UchusyaTheme(content: @Composable () -> Unit){
 MaterialTheme(colorScheme=if(isSystemInDarkTheme()) darkColorScheme() else lightColorScheme(),content=content)
}
