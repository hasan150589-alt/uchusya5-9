package com.example.uchusya59
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import com.example.uchusya59.ui.*
class MainActivity: ComponentActivity() {
 override fun onCreate(b:Bundle?) { super.onCreate(b); setContent { UchusyaTheme { Surface { AppRoot() } } } }
}
