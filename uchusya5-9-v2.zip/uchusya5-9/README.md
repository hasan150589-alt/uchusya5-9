# Учусь 5–9
Базовый Android-проект на Kotlin + Jetpack Compose.
Главные разделы: Главная, Предметы, ИИ-репетитор, Профиль.
Есть локальная Room-база для дальнейшего расширения.
Откройте проект в Android Studio и выполните `assembleDebug`.

## Сборка APK без Android Studio
Загрузите проект на GitHub (ветка main). Вкладка **Actions → Build APK** соберёт приложение.
Готовый `app-debug.apk` лежит внизу страницы запуска в разделе **Artifacts → uchusya-apk**.
