package com.example.uchusya59.model
data class Subject(val name:String,val icon:String,val progress:Int)
val demoSubjects=listOf(
 Subject("Математика","∑",68),Subject("Русский язык","А",54),
 Subject("Физика","⚡",31),Subject("История","⌛",42),
 Subject("Английский","EN",75),Subject("Информатика","</>",61))
