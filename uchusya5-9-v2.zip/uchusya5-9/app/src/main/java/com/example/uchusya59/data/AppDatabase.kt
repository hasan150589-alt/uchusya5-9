package com.example.uchusya59.data
import androidx.room.*
@Entity(tableName="notes") data class NoteEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val title:String,val text:String,val createdAt:Long=System.currentTimeMillis())
@Dao interface NoteDao {
 @Query("SELECT * FROM notes ORDER BY createdAt DESC") fun observeAll():kotlinx.coroutines.flow.Flow<List<NoteEntity>>
 @Insert suspend fun insert(note:NoteEntity)
 @Query("DELETE FROM notes WHERE id=:id") suspend fun delete(id:Long)
}
@Database(entities=[NoteEntity::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){ abstract fun noteDao():NoteDao }
